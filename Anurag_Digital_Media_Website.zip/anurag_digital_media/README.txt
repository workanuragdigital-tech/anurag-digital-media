# Anurag Digital Media Website

Open `index.html` in a browser to view the responsive single-page homepage.

Included:
- Real Anurag Digital Media logo
- Home / Artists / Releases / Distribution / Contact navigation
- Verified Artists section
- Artist Verification form
- Responsive mobile + desktop design
- Demo form submission interaction

The verification form is frontend-only in this version. Connect it to your preferred backend, Google Form, email service, or database for live submissions.
