Anurag Digital Media — Premium Homepage v2

Open index.html in a browser.

Included:
- Premium responsive homepage
- Generated Anurag Digital Media logo
- Mobile navigation
- Verified Artists section
- Releases section
- Distribution services
- Artist verification form
- Contact / email / WhatsApp placeholders

IMPORTANT:
Official WhatsApp: +91 74640 76840 | Email: workanuragdigital@gmail.com
The verification form is frontend demo-only until connected to an email/database/backend.
